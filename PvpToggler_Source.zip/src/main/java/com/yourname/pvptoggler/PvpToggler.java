package com.yourname.pvptoggler;

import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.World;

public class PvpToggler extends JavaPlugin {

    private boolean pvpEnabled = false;

    @Override
    public void onEnable() {
        Bukkit.getLogger().info("PvP Toggler Plugin Enabled!");

        // Toggle PvP every 10 minutes (12000 ticks)
        Bukkit.getScheduler().scheduleSyncRepeatingTask(this, () -> togglePvP(), 0L, 12000L);
    }

    private void togglePvP() {
        pvpEnabled = !pvpEnabled;
        for (World world : Bukkit.getWorlds()) {
            world.setPVP(pvpEnabled);
        }
        Bukkit.broadcastMessage("§aPvP is now " + (pvpEnabled ? "§cENABLED" : "§9DISABLED") + "§a!");
    }

    @Override
    public void onDisable() {
        Bukkit.getLogger().info("PvP Toggler Plugin Disabled!");
    }
}